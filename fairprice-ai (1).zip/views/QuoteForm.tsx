import React, { useState } from 'react';
import { ServiceType, QuoteInput, QuoteAnalysis, User } from '../types';
import { SERVICE_OPTIONS } from '../constants';
import { analyzeQuote } from '../services/geminiService';

interface QuoteFormProps {
  user: User | null;
  onAnalyze: (input: QuoteInput, analysis: QuoteAnalysis) => void;
  onLoginRequired: () => void;
  onUpgradeRequired: () => void;
}

export const QuoteForm: React.FC<QuoteFormProps> = ({ user, onAnalyze, onLoginRequired, onUpgradeRequired }) => {
  const [formData, setFormData] = useState<Partial<QuoteInput>>({
    serviceType: ServiceType.AUTO_REPAIR,
    location: '',
    amount: 0,
    description: '',
    rememberLocation: true,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return onLoginRequired();
    if (!formData.amount || !formData.location || !formData.description) {
      setError("All fields are required to run an audit.");
      return;
    }

    const usage = user.quoteHistory.length;
    const limit = 1 + user.shares + user.referrals;
    if (!user.isPro && !user.isTempPro && usage >= limit) return onUpgradeRequired();

    setIsSubmitting(true);
    setError(null);

    try {
      const input = { ...formData, date: new Date().toISOString() } as QuoteInput;
      const analysis = await analyzeQuote(input);
      onAnalyze(input, analysis);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-20">
      <div className="bg-white rounded-5xl shadow-[0_60px_120px_-30px_rgba(0,0,0,0.1)] border border-slate-100 overflow-hidden">
        <div className="bg-navy-900 p-12 text-center">
          <h2 className="text-4xl font-black text-white tracking-tight mb-2">Quote Audit</h2>
          <p className="text-slate-400 font-medium">Data-backed transparency for your service experts.</p>
        </div>

        <form onSubmit={handleSubmit} className="p-12 md:p-16 space-y-10">
          {error && (
            <div className="bg-rose-50 text-rose-600 p-6 rounded-3xl text-sm font-bold border border-rose-100">
              ⚠️ {error}
            </div>
          )}

          <div className="grid md:grid-cols-2 gap-10">
            <div className="space-y-4">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Service Type</label>
              <select 
                value={formData.serviceType}
                onChange={e => setFormData({...formData, serviceType: e.target.value as ServiceType})}
                className="w-full bg-slate-50 px-6 py-5 rounded-2xl border-2 border-slate-100 focus:border-blue-500 outline-none font-bold text-navy-900 appearance-none"
              >
                {SERVICE_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
            <div className="space-y-4">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Location</label>
              <input 
                type="text"
                placeholder="City, State"
                value={formData.location}
                onChange={e => setFormData({...formData, location: e.target.value})}
                className="w-full bg-slate-50 px-6 py-5 rounded-2xl border-2 border-slate-100 focus:border-blue-500 outline-none font-bold text-navy-900"
              />
            </div>
          </div>

          <div className="space-y-4">
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Quote Total ($)</label>
            <input 
              type="number"
              placeholder="0.00"
              value={formData.amount || ''}
              onChange={e => setFormData({...formData, amount: parseFloat(e.target.value)})}
              className="w-full bg-slate-50 px-8 py-6 rounded-3xl border-2 border-slate-100 focus:border-blue-500 outline-none text-5xl font-black text-navy-900 tracking-tighter"
            />
          </div>

          <div className="space-y-4">
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Description / Line Items</label>
            <textarea 
              rows={4}
              placeholder="Paste line items or describe the work..."
              value={formData.description}
              onChange={e => setFormData({...formData, description: e.target.value})}
              className="w-full bg-slate-50 px-6 py-5 rounded-2xl border-2 border-slate-100 focus:border-blue-500 outline-none font-medium text-navy-900 resize-none"
            />
          </div>

          <button 
            type="submit"
            disabled={isSubmitting}
            className={`w-full py-8 rounded-4xl font-black text-xl text-white shadow-2xl transition-all ${isSubmitting ? 'bg-slate-400' : 'bg-blue-600 hover:bg-blue-700 hover:-translate-y-1'}`}
          >
            {isSubmitting ? 'Syncing Market Data...' : 'Audit Price Now'}
          </button>
        </form>
      </div>
    </div>
  );
};