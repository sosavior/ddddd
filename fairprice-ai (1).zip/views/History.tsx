import React from 'react';
import { QuoteInput, QuoteAnalysis, User, ServiceType } from '../types';

interface HistoryProps {
  user: User;
  history: { input: QuoteInput; analysis: QuoteAnalysis }[];
  onViewDetails: (item: { input: QuoteInput; analysis: QuoteAnalysis }) => void;
}

export const History: React.FC<HistoryProps> = ({ user, history, onViewDetails }) => {
  const challengeTarget = 5;
  const progressPercent = Math.min((user.negotiationSuccessCount / challengeTarget) * 100, 100);

  return (
    <div className="max-w-5xl mx-auto px-4 py-20 space-y-16">
      <div className="bg-navy-900 rounded-5xl p-12 text-white shadow-2xl relative overflow-hidden">
        <div className="relative z-10">
          <h2 className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-4">Milestone Progress</h2>
          <h3 className="text-4xl font-black mb-8">Master Negotiator Status</h3>
          <div className="flex justify-between items-end mb-4">
            <span className="text-xs font-black uppercase tracking-widest">{user.negotiationSuccessCount} / {challengeTarget} Successes</span>
            <span className="text-xs font-bold text-slate-400">{Math.round(progressPercent)}% to Pro Unlock</span>
          </div>
          <div className="h-4 bg-white/10 rounded-full overflow-hidden border border-white/5">
            <div className="h-full bg-blue-500 shadow-[0_0_30px_rgba(59,130,246,0.6)] transition-all duration-1000" style={{ width: `${progressPercent}%` }}></div>
          </div>
        </div>
        <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none">
          <span className="text-[15rem] leading-none">🏆</span>
        </div>
      </div>

      <div className="space-y-8">
        <h2 className="text-3xl font-black text-navy-900">Your Audit History</h2>
        {history.length === 0 ? (
          <div className="bg-white p-24 rounded-4xl text-center border border-slate-100">
            <p className="text-slate-400 font-bold uppercase tracking-widest">No audits yet.</p>
          </div>
        ) : (
          <div className="grid gap-6">
            {history.map((h, i) => (
              <div 
                key={i} 
                onClick={() => onViewDetails(h)}
                className="bg-white p-8 rounded-4xl border border-slate-100 flex flex-col md:flex-row items-center justify-between hover:border-blue-300 hover:shadow-xl cursor-pointer transition-all gap-8"
              >
                <div className="flex items-center gap-6">
                  <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-3xl shadow-inner">
                    {h.input.serviceType === ServiceType.AUTO_REPAIR ? '🚗' : '🔧'}
                  </div>
                  <div>
                    <h4 className="text-xl font-black text-navy-900">{h.input.serviceType}</h4>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{h.input.location} • {new Date(h.input.date).toLocaleDateString()}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-black text-slate-400 uppercase mb-1">Quote: ${h.input.amount}</p>
                  <p className={`text-sm font-black ${h.analysis.savingsEstimate > 0 ? 'text-emerald-600' : 'text-slate-400'}`}>
                    Saved: ${h.analysis.savingsEstimate}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};