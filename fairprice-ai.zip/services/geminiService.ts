import { GoogleGenAI, Type } from "@google/genai";
import { QuoteInput, QuoteAnalysis } from "../types";

export const analyzeQuote = async (input: QuoteInput, isSecondOpinion: boolean = false): Promise<QuoteAnalysis> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const analysisSchema = {
    type: Type.OBJECT,
    properties: {
      fairRangeMin: { type: Type.NUMBER, description: "Min fair price" },
      fairRangeMax: { type: Type.NUMBER, description: "Max fair price" },
      marketMedian: { type: Type.NUMBER, description: "Avg market price" },
      overpaymentPercent: { type: Type.NUMBER, description: "Overpay %" },
      savingsEstimate: { type: Type.NUMBER, description: "Potential savings" },
      predictiveSavingsAnnual: { type: Type.NUMBER, description: "Estimated annual savings for this user category" },
      fairnessRating: { type: Type.STRING },
      analysisReasoning: { type: Type.STRING },
      recommendedProviders: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            rating: { type: Type.NUMBER },
            reviewCount: { type: Type.NUMBER },
            estimatedSavings: { type: Type.NUMBER }
          },
          required: ["name", "rating", "reviewCount", "estimatedSavings"]
        }
      },
      negotiationTemplates: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            tone: { type: Type.STRING },
            subject: { type: Type.STRING },
            message: { type: Type.STRING }
          },
          required: ["tone", "subject", "message"]
        }
      }
    },
    required: [
      "fairRangeMin", 
      "fairRangeMax", 
      "marketMedian", 
      "overpaymentPercent", 
      "savingsEstimate", 
      "predictiveSavingsAnnual",
      "fairnessRating", 
      "analysisReasoning", 
      "negotiationTemplates",
      "recommendedProviders"
    ]
  };

  const prompt = `
    Analyze this service quote for fairness in the specific local market:
    Service: ${input.serviceType}
    Location: ${input.location}
    Quote: $${input.amount}
    Details: ${input.description}

    Tasks:
    1. Research current fair market rates for this service in ${input.location} using Google Search.
    2. Provide a detailed breakdown of whether the quote is fair.
    3. Generate 3 negotiation templates: Polite, Firm, and Aggressive.
    4. Suggest 3 alternative providers in the ${input.location} area.
    5. Estimate potential annual savings for a user auditing all their major service quotes.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
      },
    });

    const result = JSON.parse(response.text || '{}') as QuoteAnalysis;
    
    // Extract search sources for grounding transparency
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    const sources = groundingChunks?.map((chunk: any) => ({
      title: chunk.web?.title || 'Market Source',
      uri: chunk.web?.uri || '#'
    })) || [];

    return { ...result, sources };
  } catch (error) {
    console.error("Analysis Error:", error);
    throw new Error("Unable to analyze market data at this moment. Please check your inputs.");
  }
};