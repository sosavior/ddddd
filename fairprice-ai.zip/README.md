
# 🚀 My FairPrice AI

This is your private copy of the FairPrice AI application.

## 🏁 How to Launch (The Easy Way)
1. **Open `LAUNCH_GUIDE.html`** on your computer.
2. Follow the 3 steps inside.
3. Your app will be live on a custom URL in minutes.

## 📁 Key Files for You
- `constants.ts`: Change your app's name and colors here.
- `views/Home.tsx`: Change the text on your homepage here.
- `metadata.json`: Change the app's description for Google search here.

## 🛠 Features
- **AI Price Auditing**: Uses Google Search to find real local labor rates.
- **Negotiation Scripts**: Professional templates to help you save money.
- **Pro Features**: Built-in payment screens and "refer-a-friend" rewards.
