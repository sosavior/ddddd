import React from 'react';
import { APP_NAME, UI_COLORS } from '../constants';
import { ViewState } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  activeView: ViewState;
  onNavigate: (view: ViewState) => void;
  isLoggedIn: boolean;
  onLogout: () => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, activeView, onNavigate, isLoggedIn, onLogout }) => {
  return (
    <div className={`min-h-screen bg-slate-50 flex flex-col font-sans`}>
      <header className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div 
            className="flex items-center gap-3 cursor-pointer group" 
            onClick={() => onNavigate('HOME')}
          >
            <div className={`w-10 h-10 bg-${UI_COLORS.primary} rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform`}>
              <span className="text-white font-black text-xl italic">F</span>
            </div>
            <span className="text-xl font-black text-navy-900 tracking-tight">{APP_NAME}</span>
          </div>

          <nav className="hidden md:flex items-center gap-10">
            {['HOME', 'FORM', 'HISTORY'].map((v) => {
              if (v === 'HISTORY' && !isLoggedIn) return null;
              return (
                <button 
                  key={v}
                  onClick={() => onNavigate(v as ViewState)}
                  className={`text-sm font-bold uppercase tracking-widest ${activeView === v ? `text-${UI_COLORS.primary}` : 'text-slate-400'} hover:text-navy-900 transition-colors`}
                >
                  {v === 'FORM' ? 'Check Quote' : v.toLowerCase()}
                </button>
              );
            })}
          </nav>

          <div className="flex items-center gap-4">
            {isLoggedIn ? (
              <div className="flex items-center gap-6">
                <button onClick={onLogout} className="text-xs font-black text-slate-400 hover:text-rose-500 uppercase tracking-widest">Logout</button>
                <button 
                  onClick={() => onNavigate('UPGRADE')}
                  className={`bg-emerald-500 text-white px-6 py-2.5 rounded-full text-xs font-black uppercase tracking-widest hover:bg-emerald-600 transition-all shadow-md`}
                >
                  Go Pro
                </button>
              </div>
            ) : (
              <button 
                onClick={() => onNavigate('LOGIN')}
                className={`bg-navy-900 text-white px-8 py-3 rounded-full text-xs font-black uppercase tracking-widest hover:bg-blue-600 transition-all shadow-xl`}
              >
                Sign In
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="flex-grow">
        {children}
      </main>

      <footer className="bg-white border-t border-slate-200 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex flex-col items-center gap-4">
            <div className="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center mb-4">
              <span className="text-slate-400 font-bold">F</span>
            </div>
            <p className="text-slate-400 text-xs font-bold uppercase tracking-[0.3em]">
              © {new Date().getFullYear()} {APP_NAME} GLOBAL
            </p>
            <p className="text-slate-300 text-[10px] max-w-sm">
              Providing algorithmic transparency for home and auto service markets since 2024.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};