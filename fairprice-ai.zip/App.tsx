import React, { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { Home } from './views/Home';
import { QuoteForm } from './views/QuoteForm';
import { Results } from './views/Results';
import { History } from './views/History';
import { Login } from './views/Login';
import { Upgrade } from './views/Upgrade';
import { ViewState, User, QuoteInput, QuoteAnalysis } from './types';
import { analyzeQuote } from './services/geminiService';

const App: React.FC = () => {
  const [view, setView] = useState<ViewState>('HOME');
  const [user, setUser] = useState<User | null>(null);
  const [currentAnalysis, setCurrentAnalysis] = useState<{ input: QuoteInput; analysis: QuoteAnalysis } | null>(null);
  const [isRequestingSecondOpinion, setIsRequestingSecondOpinion] = useState(false);

  useEffect(() => {
    const savedUser = localStorage.getItem('fairprice_user');
    if (savedUser) {
      const parsed = JSON.parse(savedUser);
      if (parsed.tempProUntil && new Date(parsed.tempProUntil) < new Date()) {
        parsed.isTempPro = false;
        parsed.tempProUntil = undefined;
      }
      setUser(parsed);
    }
  }, []);

  useEffect(() => {
    if (user) {
      localStorage.setItem('fairprice_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('fairprice_user');
    }
  }, [user]);

  const handleLogin = (email: string) => {
    const newUser: User = {
      email,
      isPro: false,
      quoteHistory: [],
      referrals: 0,
      shares: 0,
      negotiationSuccessCount: 0
    };
    setUser(newUser);
    setView('HOME');
  };

  const handleFeedback = (feedback: 'helpful' | 'not_helpful' | 'negotiated_success') => {
    if (!currentAnalysis || !user) return;
    
    const isSuccess = feedback === 'negotiated_success';
    const updatedAnalysis = { ...currentAnalysis.analysis, userFeedback: feedback };
    const updatedItem = { ...currentAnalysis, analysis: updatedAnalysis };
    
    setCurrentAnalysis(updatedItem);

    const newSuccessCount = isSuccess ? user.negotiationSuccessCount + 1 : user.negotiationSuccessCount;
    
    let isTempPro = user.isTempPro;
    let tempProUntil = user.tempProUntil;
    if (newSuccessCount >= 5 && !user.isPro && !user.isTempPro) {
      isTempPro = true;
      const date = new Date();
      date.setDate(date.getDate() + 7);
      tempProUntil = date.toISOString();
    }

    const updatedHistory = user.quoteHistory.map(h => 
      h.input.date === currentAnalysis.input.date ? updatedItem : h
    );
    
    setUser({ 
      ...user, 
      quoteHistory: updatedHistory, 
      negotiationSuccessCount: newSuccessCount,
      isTempPro,
      tempProUntil
    });
  };

  const handleViralAction = (type: 'share' | 'refer') => {
    if (!user) return;
    const update = type === 'share' ? { shares: user.shares + 1 } : { referrals: user.referrals + 1 };
    setUser({ ...user, ...update });
    alert(`Reward Unlocked! Your ${type === 'share' ? 'sharing' : 'referral'} has granted you 1 extra quote analysis.`);
  };

  const renderView = () => {
    switch (view) {
      case 'HOME': return <Home onStart={() => setView('FORM')} />;
      case 'FORM': return (
        <QuoteForm 
          user={user} 
          onAnalyze={(input, analysis) => {
            setCurrentAnalysis({ input, analysis });
            if (user) setUser({ ...user, quoteHistory: [{ input, analysis }, ...user.quoteHistory] });
            setView('RESULTS');
          }} 
          onLoginRequired={() => setView('LOGIN')}
          onUpgradeRequired={() => setView('UPGRADE')}
        />
      );
      case 'RESULTS': return currentAnalysis && (
        <Results 
          input={currentAnalysis.input} 
          analysis={currentAnalysis.analysis} 
          onNewQuote={() => setView('FORM')}
          onGetSecondOpinion={async () => {
            setIsRequestingSecondOpinion(true);
            try {
              const res = await analyzeQuote(currentAnalysis.input, true);
              setCurrentAnalysis({ ...currentAnalysis, analysis: { ...currentAnalysis.analysis, secondOpinion: res } });
            } catch (e) {
              alert("Second opinion failed. Check your connection.");
            } finally { setIsRequestingSecondOpinion(false); }
          }}
          isLoadingSecondOpinion={isRequestingSecondOpinion}
          onFeedback={handleFeedback}
          onShare={() => handleViralAction('share')}
          onRefer={() => handleViralAction('refer')}
        />
      );
      case 'HISTORY': return user && (
        <History 
          user={user}
          history={user.quoteHistory} 
          onViewDetails={(item) => { setCurrentAnalysis(item); setView('RESULTS'); }} 
        />
      );
      case 'LOGIN': return <Login onLogin={handleLogin} />;
      case 'UPGRADE': return <Upgrade onUpgrade={() => { setUser(user ? { ...user, isPro: true } : null); setView('HOME'); }} onBack={() => setView('FORM')} />;
      default: return <Home onStart={() => setView('FORM')} />;
    }
  };

  return (
    <Layout activeView={view} onNavigate={setView} isLoggedIn={!!user} onLogout={() => setUser(null)}>
      {renderView()}
    </Layout>
  );
};

export default App;