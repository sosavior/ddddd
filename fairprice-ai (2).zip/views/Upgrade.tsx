
import React from 'react';
import { UI_COLORS } from '../constants';

interface UpgradeProps {
  onUpgrade: () => void;
  onBack: () => void;
}

export const Upgrade: React.FC<UpgradeProps> = ({ onUpgrade, onBack }) => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-16">
      <div className="text-center mb-16">
        <div className="inline-block px-4 py-1.5 rounded-full bg-blue-50 border border-blue-100 text-blue-600 text-[10px] font-black uppercase tracking-widest mb-6">
          Limited Time: 30-Day Money Back Guarantee
        </div>
        <h2 className="text-4xl md:text-5xl font-black text-navy-900 mb-4 tracking-tight">Protect Your Wallet with Pro</h2>
        <p className="text-xl text-slate-600 max-w-2xl mx-auto font-light">
          One successful negotiation pays for years of FairPrice Pro. Join 12,000+ smart homeowners.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 items-stretch mb-12">
        {/* Monthly Plan */}
        <div className="bg-white rounded-[2.5rem] p-10 border border-slate-200 shadow-sm hover:border-blue-200 transition-all flex flex-col">
          <h3 className="text-lg font-black text-slate-400 uppercase tracking-widest mb-2">Monthly</h3>
          <div className="text-5xl font-black text-navy-900 mb-6 tracking-tighter">$8.99<span className="text-lg text-slate-400 font-medium tracking-normal">/mo</span></div>
          
          <ul className="space-y-4 mb-10 text-sm flex-grow">
            <li className="flex items-center gap-3 text-slate-600">
              <span className="text-emerald-500 font-bold">✓</span> Unlimited Quote Analyses
            </li>
            <li className="flex items-center gap-3 text-slate-600">
              <span className="text-emerald-500 font-bold">✓</span> Advanced Negotiation Scripts
            </li>
            <li className="flex items-center gap-3 text-slate-600">
              <span className="text-emerald-500 font-bold">✓</span> AI Provider Recommendations
            </li>
          </ul>

          <button 
            onClick={onUpgrade}
            className="w-full py-4 rounded-2xl border-2 border-navy-900 text-navy-900 font-black hover:bg-navy-900 hover:text-white transition-all mb-4"
          >
            Select Monthly
          </button>
        </div>

        {/* Yearly Plan - The Primary Target */}
        <div className="bg-white rounded-[2.5rem] p-10 border-4 border-blue-600 shadow-2xl relative transform md:scale-105 flex flex-col">
          <div className="absolute -top-5 left-1/2 -translate-x-1/2 bg-blue-600 text-white px-6 py-1.5 rounded-full text-xs font-black uppercase tracking-[0.2em] shadow-lg">
            Best Value - Save 49%
          </div>
          
          <h3 className="text-lg font-black text-blue-600 uppercase tracking-widest mb-2">Annual Pass</h3>
          <div className="text-6xl font-black text-navy-900 mb-6 tracking-tighter">$54.99<span className="text-lg text-slate-400 font-medium tracking-normal">/year</span></div>
          
          <ul className="space-y-4 mb-10 text-sm flex-grow">
            <li className="flex items-center gap-3 text-navy-900 font-bold">
              <span className="text-emerald-500 font-black">✓</span> Everything in Monthly
            </li>
            <li className="flex items-center gap-3 text-navy-900 font-bold">
              <span className="text-emerald-500 font-black">✓</span> Premium "Auditor" AI Model
            </li>
            <li className="flex items-center gap-3 text-navy-900 font-bold">
              <span className="text-emerald-500 font-black">✓</span> Early Access to New Data Cities
            </li>
            <li className="flex items-center gap-3 text-navy-900 font-bold">
              <span className="text-emerald-500 font-black">✓</span> 24/7 Negotiation Support
            </li>
          </ul>

          <div className="space-y-3">
            <button 
              onClick={onUpgrade}
              className="w-full py-5 rounded-2xl font-black text-white bg-blue-600 hover:bg-blue-700 transition-all shadow-xl shadow-blue-200 transform active:scale-95"
            >
              Go Pro Yearly
            </button>
            
            {/* Express Payment Section */}
            <div className="pt-2">
              <div className="flex items-center gap-2 mb-3">
                <div className="h-px bg-slate-100 flex-grow"></div>
                <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Express Checkout</span>
                <div className="h-px bg-slate-100 flex-grow"></div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button 
                  onClick={onUpgrade}
                  className="flex items-center justify-center py-3 bg-[#0070ba] hover:bg-[#005ea6] rounded-xl transition-all"
                  title="Pay with PayPal"
                >
                  <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" alt="PayPal" className="h-5 brightness-0 invert" />
                </button>
                <button 
                  onClick={onUpgrade}
                  className="flex items-center justify-center py-3 bg-[#3d95ce] hover:bg-[#2c84bc] rounded-xl transition-all"
                  title="Pay with Venmo"
                >
                  <img src="https://upload.wikimedia.org/wikipedia/commons/a/ae/Venmo_logo.svg" alt="Venmo" className="h-5 brightness-0 invert" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Shared Payment Icons & Trust Ribbons */}
      <div className="max-w-xl mx-auto text-center mb-16">
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-6">Securely processed by Stripe & PayPal</p>
        <div className="flex flex-wrap items-center justify-center gap-8 opacity-40 grayscale hover:grayscale-0 transition-all duration-700">
           <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" className="h-4" alt="Visa" />
           <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" className="h-6" alt="Mastercard" />
           <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" className="h-4" alt="PayPal" />
           <img src="https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg" className="h-5" alt="Apple Pay" />
           <img src="https://upload.wikimedia.org/wikipedia/commons/3/30/American_Express_logo_%282018%29.svg" className="h-5" alt="AMEX" />
        </div>
      </div>

      {/* Trust Signal / Guarantee */}
      <div className="bg-slate-100 rounded-[2.5rem] p-8 md:p-12 flex flex-col md:flex-row items-center gap-10 border border-slate-200">
        <div className="relative">
          <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center text-4xl shadow-lg border border-slate-50 rotate-3 transform">🛡️</div>
          <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white shadow-lg">
             <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path></svg>
          </div>
        </div>
        <div className="text-center md:text-left flex-1">
          <h4 className="font-black text-navy-900 uppercase tracking-widest text-xs mb-2">The FairPrice ROI Guarantee</h4>
          <p className="text-slate-500 text-base font-medium leading-relaxed">If FairPrice AI doesn't identify at least $100 in potential savings within your first 3 audits, contact us for a full refund. We also accept returns via PayPal and Venmo protection programs.</p>
        </div>
        <div className="flex flex-col items-center border-t md:border-t-0 md:border-l border-slate-200 pt-8 md:pt-0 md:pl-10">
           <span className="text-xs font-black text-navy-900 tracking-tighter">BANK-LEVEL</span>
           <span className="text-2xl font-black text-navy-900">256-BIT</span>
           <span className="text-[10px] font-bold text-slate-400 uppercase">SSL Encryption</span>
        </div>
      </div>

      <div className="mt-16 text-center">
        <button onClick={onBack} className="text-slate-400 hover:text-navy-900 font-black text-[10px] uppercase tracking-[0.3em] transition-all hover:tracking-[0.4em]">
          ← Continue with basic limited plan
        </button>
      </div>
    </div>
  );
};
