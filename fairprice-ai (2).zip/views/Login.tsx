
import React, { useState } from 'react';
import { UI_COLORS } from '../constants';

interface LoginProps {
  onLogin: (email: string) => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setIsLoading(true);
    // Brief artificial delay for a premium feel before direct login
    setTimeout(() => {
      setIsLoading(false);
      onLogin(email);
    }, 800);
  };

  return (
    <div className="max-w-md mx-auto px-4 py-24">
      <div className="bg-white rounded-[3rem] p-12 shadow-2xl border border-gray-100 animate-in fade-in slide-in-from-bottom-8 duration-700">
        <div className="text-center mb-10">
          <div className={`w-20 h-20 bg-${UI_COLORS.primary} rounded-[2rem] flex items-center justify-center mx-auto mb-8 text-white text-4xl font-black shadow-xl rotate-3 transform hover:rotate-0 transition-transform`}>
            F
          </div>
          <h2 className="text-3xl font-black text-navy-900 tracking-tight">Welcome Back</h2>
          <p className="text-slate-500 mt-3 font-medium text-sm">Enter your email to access your dashboard.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="space-y-3">
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-1">Email Address</label>
            <div className="relative group">
              <input 
                type="email" 
                required
                placeholder="name@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-6 py-5 rounded-2xl border-2 border-slate-100 focus:border-blue-500 outline-none transition-all font-bold text-navy-900 bg-slate-50 placeholder:text-slate-300"
              />
              <div className="absolute inset-0 rounded-2xl border-2 border-blue-500 opacity-0 group-focus-within:opacity-100 pointer-events-none transition-opacity scale-[1.02]"></div>
            </div>
          </div>

          <button 
            type="submit"
            disabled={isLoading}
            className={`w-full py-6 rounded-[2rem] font-black text-sm uppercase tracking-[0.2em] text-white shadow-2xl transition-all active:scale-95 flex items-center justify-center gap-3 ${
              isLoading ? 'bg-slate-400' : `bg-navy-900 hover:bg-blue-600 shadow-blue-100`
            }`}
          >
            {isLoading ? (
              <svg className="animate-spin h-5 w-5 text-white" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            ) : (
              <>
                Sign In Now
                <span className="text-lg">→</span>
              </>
            )}
          </button>
        </form>

        <div className="mt-12 pt-10 border-t border-slate-50 text-center">
          <p className="text-[10px] text-slate-400 font-bold leading-relaxed max-w-[240px] mx-auto">
            Secure 256-bit encrypted session. Your data is never shared with third parties.
          </p>
        </div>
      </div>

      <div className="mt-8 text-center">
        <p className="text-[10px] font-black text-slate-300 uppercase tracking-[0.4em]">FairPrice AI Protocol v4.2</p>
      </div>
    </div>
  );
};
