export enum ServiceType {
  AUTO_REPAIR = 'Auto Repair',
  PLUMBING = 'Plumbing',
  HVAC = 'HVAC',
  PHONE_REPAIR = 'Phone Repair',
  CLEANING = 'Cleaning',
  MOVING = 'Moving',
  ELECTRICIAN = 'Electrician',
  OTHER = 'Other'
}

export enum ToneType {
  POLITE = 'Polite',
  FIRM = 'Firm',
  AGGRESSIVE = 'Aggressive'
}

export interface ProviderRecommendation {
  name: string;
  rating: number;
  reviewCount: number;
  estimatedSavings: number;
  uri?: string;
}

export interface QuoteInput {
  id?: string;
  serviceType: ServiceType;
  location: string;
  amount: number;
  description: string;
  date: string;
  imageUrl?: string;
  rememberLocation?: boolean;
}

export interface NegotiationTemplate {
  tone: ToneType;
  subject: string;
  message: string;
}

export interface QuoteAnalysis {
  fairRangeMin: number;
  fairRangeMax: number;
  marketMedian: number;
  overpaymentPercent: number;
  savingsEstimate: number;
  predictiveSavingsAnnual: number;
  fairnessRating: 'Fair' | 'Slightly High' | 'Overpriced' | 'Extremely Overpriced';
  analysisReasoning: string;
  negotiationTemplates: NegotiationTemplate[];
  recommendedProviders: ProviderRecommendation[];
  sources: { title: string; uri: string }[];
  secondOpinion?: QuoteAnalysis;
  userFeedback?: 'helpful' | 'not_helpful' | 'negotiated_success';
}

export interface User {
  email: string;
  isPro: boolean;
  isTempPro?: boolean;
  tempProUntil?: string;
  quoteHistory: { input: QuoteInput; analysis: QuoteAnalysis }[];
  referrals: number;
  shares: number;
  negotiationSuccessCount: number;
}

export type ViewState = 'HOME' | 'FORM' | 'RESULTS' | 'HISTORY' | 'LOGIN' | 'UPGRADE';