import { ServiceType } from './types';

export const SERVICE_OPTIONS = Object.values(ServiceType);

/**
 * 🏷️ YOUR BRAND NAME
 */
export const APP_NAME = 'FairPrice AI';

/**
 * 🎨 YOUR BRAND COLORS
 */
export const UI_COLORS = {
  primary: 'blue-600',
  primaryDark: 'blue-700',
  secondary: 'emerald-500',
  accent: 'indigo-600',
  danger: 'rose-500',
  background: 'slate-50'
};